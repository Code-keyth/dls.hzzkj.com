<?php
/**
 * Created by PhpStorm.
 * User: FX55
 * Date: 17.10.1
 * Time: 9:38
 */

namespace app\common\model;
use think\Model;
use app\common\model\Goodtype;
class Project extends Model
{
    public function GoodtypeName($id){
       return Goodtype::get($id);
    }
    public function MemberName($id){
        return Member::get($id);
    }
    public function pro_name($id){
        return Project::get($id)->getdata('name');
    }

}