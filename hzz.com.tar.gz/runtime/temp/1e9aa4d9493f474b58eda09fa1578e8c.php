<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"/home/wwwroot/hzz.com/application/admin/view/index/project_list.html";i:1508053596;}*/ ?>
﻿<!DOCTYPE HTML>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<!--[if lt IE 9]>
<script type="text/javascript" src="_ADMIN/lib/html5shiv.js"></script>
<script type="text/javascript" src="_ADMIN/lib/respond.min.js"></script>
<![endif]-->
<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui/css/H-ui.min.css" />
<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/css/H-ui.admin.css" />
<link rel="stylesheet" type="text/css" href="_ADMIN/lib/Hui-iconfont/1.0.8/iconfont.css" />
<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/skin/default/skin.css" id="skin" />
<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/css/style.css" />
<!--[if IE 6]>
<script type="text/javascript" src="_ADMIN/lib/DD_belatedPNG_0.0.8a-min.js" ></script>
<script>DD_belatedPNG.fix('*');</script>
<![endif]-->
<title>项目管理</title>
</head>
<body>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span> 项目管理 <span class="c-gray en">&gt;</span> 项目列表 <a class="btn btn-success radius r" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a></nav>
<div class="page-container" style="padding-top: 20px;">
	<div class="text-c">
		<form method="get" action="<?php echo url('project_list'); ?>?">
							<span class="select-box inline">
				<select name="id" class="select">
					<option value="">所有代理商 </option>
					<?php if(is_array($members_dls) || $members_dls instanceof \think\Collection || $members_dls instanceof \think\Paginator): $i = 0; $__LIST__ = $members_dls;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$dls): $mod = ($i % 2 );++$i;?>0
					<option <?php if($getid == $dls->getdata('id')): ?>selected = "selected"<?php endif; ?> value="<?php echo $dls->getdata('id'); ?>"><?php echo $dls->getdata('username'); ?></option>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</select>
				</span>



		<button name="" id="" class="btn btn-success" type="submit"><i class="Hui-iconfont">&#xe665;</i> 查看</button>
		</form>
	</div>

	<div class="cl pd-5 bg-1 bk-gray mt-20"> <span class="l"><a href="javascript:;" id="projects_del" onclick="projects_del()" class="btn btn-danger radius"><i class="Hui-iconfont">&#xe6e2;</i> 批量删除</a></span> <span class="r">共有数据：<strong><?php echo count($projects); ?></strong> 条</span> </div>
	<div class="mt-20">
		<table class="table table-border table-bordered table-bg table-sort">
			<thead>
				<tr class="text-c">
					<th width="25"><input type="checkbox" name="" value=""></th>
					<th width="150">ID</th>
					<th width="150">代理商</th>

					<th width="200">产品类别</th>
					<th width="200">项目名称</th>

					<th width="200">目前状态</th>
					<th width="200">执行人</th>

					<th width="100">操作</th>
				</tr>
			</thead>
			<tbody>
				<?php if(is_array($projects) || $projects instanceof \think\Collection || $projects instanceof \think\Paginator): $i = 0; $__LIST__ = $projects;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$project): $mod = ($i % 2 );++$i;?>
				<tr class="text-c">
					<td><input name="" type="checkbox" value="<?php echo $project->getdata('id'); ?>"></td>
					<td><?php echo $key+1; ?></td>
					<td><?php echo $project->MemberName($project->getdata('mid'))['username']; ?></td>
					<td><?php echo $project->GoodtypeName($project->getdata('type'))['name']; ?></td>
					<td class="text-l"><?php echo $project->getdata('name'); ?></td>
					<td class="text-l" id="state">       【
					 							<?php if($project->getdata('state') == '0'): ?>待确认订单 <?php endif; if($project->getdata('state') == '1'): ?>策划方案<?php endif; if($project->getdata('state') == '2'): ?>确认开发<?php endif; if($project->getdata('state') == '3'): ?>程序开发<?php endif; if($project->getdata('state') == '4'): ?>资料填充<?php endif; if($project->getdata('state') == '5'): ?>程序体验及修改<?php endif; if($project->getdata('state') == '6'): ?>尾款支付<?php endif; if($project->getdata('state') == '7'): ?>项目完成<?php endif; ?>

						                                              】

						<button class="btn btn-success"	onclick="project_state(<?php echo $project->getdata('state'); ?>,<?php echo $project->getdata('id'); ?>)"> 进入下阶段</button>









					</td>

					<td class="text-l"><?php echo $project->getdata('executor'); ?></td>
					<td class="f-14 product-brand-manage">
						<a style="text-decoration:none" href="<?php echo url('project_add'); ?>?id=<?php echo $project->getdata('id'); ?>" title="编辑"><i class="Hui-iconfont">&#xe6df;</i></a>
						<a style="text-decoration:none" class="ml-5" onClick="project_del(this,<?php echo $project->getdata('id'); ?>)" href="javascript:;" title="删除"><i class="Hui-iconfont">&#xe6e2;</i></a></td>

					<td style="display: none;"> </td>
				</tr>
<?php endforeach; endif; else: echo "" ;endif; ?>

			</tbody>
		</table>

		<div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
			<?php echo $projects->render(); ?>
		</div>


	</div>
</div>
<!--_footer 作为公共模版分离出去-->
<script type="text/javascript" src="_ADMIN/lib/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="_ADMIN/lib/layer/2.4/layer.js"></script>
<script type="text/javascript" src="_ADMIN/static/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="_ADMIN/static/h-ui.admin/js/H-ui.admin.js"></script> <!--/_footer 作为公共模版分离出去-->

<!--请在下方写此页面业务相关的脚本-->
<script type="text/javascript" src="_ADMIN/lib/My97DatePicker/4.8/WdatePicker.js"></script> 
<script type="text/javascript" src="_ADMIN/lib/datatables/1.10.0/jquery.dataTables.min.js"></script> 
<script type="text/javascript" src="_ADMIN/lib/laypage/1.2/laypage.js"></script>
<script type="text/javascript">
	$('.table-sort').dataTable({
		"aaSorting": [[ 1, "desc" ]],//默认第几个排序
		"bStateSave": true,//状态保存
		"aoColumnDefs": [
			//{"bVisible": false, "aTargets": [ 3 ]} //控制列的隐藏显示
			{"orderable":false,"aTargets":[0,6]}// 制定列不参与排序
		]
	});
	/*项目-进度*/
	function project_state(state,id){
		layer.confirm('确定项目进行到下一阶段吗？',function(index){
			$.get("<?php echo url('project_state'); ?>",{ "state": state,"id":id},function(){
				layer.msg('完成!',{icon:1,time:3000},history.go(0));


			});
		});
	}
/*项目-删除*/
function project_del(obj,id){
	layer.confirm('确认要删除吗？',function(index){
		$.get("<?php echo url('project_delect'); ?>",{ "id": id},function(){
			$(obj).parents("tr").remove();
			layer.msg('已删除!',{icon:1,time:1000});
		});
	});
}

/*项目-批量删除*/
function projects_del(){
	layer.confirm('确认要删除吗？',function(index){
		$.each($('input:checkbox'),function(){
			if(this.checked){
				$(this).parents("tr").remove();
				$.get("<?php echo url('project_delect'); ?>",{ "id": $(this).val()},function(){
					//$(obj).parents("tr").remove();
					layer.msg('已删除!',{icon:1,time:1000});
				});

				/*window.alert("你选了："+
				 $('input[type=checkbox]:checked').length+"个，其中有："+$(this).val());*/
			}
		});

	});
}


</script>
</body>
</html>