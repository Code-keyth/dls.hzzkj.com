<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:66:"/home/wwwroot/hzz.com/application/admin/view/index/fapiao_add.html";i:1508156017;}*/ ?>
﻿<!--_meta 作为公共模版分离出去-->
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="Bookmark" href="/favicon.ico" >
<link rel="Shortcut Icon" href="/favicon.ico" />
<!--[if lt IE 9]>
<script type="text/javascript" src="_ADMIN/lib/html5shiv.js"></script>
<script type="text/javascript" src="_ADMIN/lib/respond.min.js"></script>

<![endif]-->
<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui/css/H-ui.min.css" />
<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/css/H-ui.admin.css" />
<link rel="stylesheet" type="text/css" href="_ADMIN/lib/Hui-iconfont/1.0.8/iconfont.css" />
<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/skin/default/skin.css" id="skin" />
<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/css/style.css" />
<!--[if IE 6]>
<script type="text/javascript" src="_ADMIN/lib/DD_belatedPNG_0.0.8a-min.js" ></script>
<script>DD_belatedPNG.fix('*');</script>
<![endif]-->
<!--/meta 作为公共模版分离出去-->
<link href="_ADMIN/lib/webuploader/0.1.5/webuploader.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="page-container">
	<form action="<?php echo url('fapiao_add_c'); ?>" method="post" class="form form-horizontal" id="">
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>发票类型：</label>
			<div class="formControls col-xs-8 col-sm-9"> <span class="select-box">
				<select name="type" class="select field">
					<option value="增值税普通发票">增值税普通发票(小规模纳税人) </option>
					<option value="增值税专用发票">增值税专用发票(一般纳税人)</option>
				</select>
				</span> </div>
		</div>
		<div class="row cl  field2">
			<label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>纳税人识别号：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" class="input-text" value="<?php echo $fapiao['taxnumber']; ?>" placeholder="" id="" name="taxnumber">
			</div>
		</div>
		<div class="row cl  field2">
			<label class="form-label col-xs-4 col-sm-2 "><span class="c-red">*</span>开户行：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" class="input-text" value="<?php echo $fapiao['khh']; ?>" placeholder="" id="" name="khh">
			</div>
		</div>
		<div class="row cl  field2">
			<label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span> 开户账号：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" class="input-text" value="<?php echo $fapiao['khzh']; ?>" placeholder="" id="" name="khzh">
			</div>
		</div>
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>开票地址：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" class="input-text" value="<?php echo $fapiao['kpdz']; ?>" placeholder="" id="" name="kpdz">
			</div>
		</div>

		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>预留电话：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" class="input-text" value="<?php echo $fapiao['yldh']; ?>" placeholder="" id="" name="yldh">
			</div>
		</div>
        <?php if(isset($off)): ?>
        <div class="row cl" hidden >
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" class="input-text" value="<?php echo $fapiao['id']; ?>" placeholder="" id="" name="id">
            </div>
        </div>
        <?php endif; ?>
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span> 发票抬头：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" class="input-text" value="<?php echo $fapiao['rise']; ?>" placeholder="" id="" name="rise">
			</div>
		</div>
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-2">发票金额：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" name="price" id="" placeholder="" value="<?php echo $fapiao['price']; ?>" class="input-text" style="width:90%">
				元</div>
		</div>
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>发票内容：</label>
			<div class="formControls col-xs-8 col-sm-9"> <span class="select-box">
				<select name="fpnr" class="select">
					<option value="0">软件服务费用 </option>
				</select>
				</span> </div>
		</div>

		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>收件方地址：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" class="input-text" value="<?php echo $fapiao['sjfdz']; ?>" placeholder="" id="" name="sjfdz">
			</div>
		</div>
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span> 收 件 人：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" class="input-text" value="<?php echo $fapiao['sjr']; ?>" placeholder="" id="" name="sjr">
			</div>
		</div>

		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>邮政编码：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" class="input-text" value="<?php echo $fapiao['yzbm']; ?>" placeholder="" id="" name="yzbm">
			</div>
		</div>

		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>联系电话：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" class="input-text" value="<?php echo $fapiao['mobile']; ?>" placeholder="" id="" name="mobile">
			</div>
		</div>
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-2">备注信息：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<textarea name="describe" cols="" rows="" class="textarea"  placeholder="说点什么...最少输入10个字符" datatype="*10-100" dragonfly="true" nullmsg="备注不能为空！" onKeyUp="$.Huitextarealength(this,200)"><?php echo $fapiao['describe']; ?></textarea>
				<p class="textarea-numberbar"><em class="textarea-length">0</em>/200</p>
			</div>
		</div>
		<div class="row cl">
			<div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-2">
				<button  class="btn btn-primary radius" type="submit"><i class="Hui-iconfont">&#xe632;</i> 保存并提交审核</button>
			</div>
		</div>
	</form>
</div>
<!--_footer 作为公共模版分离出去-->
<script type="text/javascript" src="_ADMIN/lib/jquery/1.9.1/jquery.min.js"></script> 
<script type="text/javascript" src="_ADMIN/lib/layer/2.4/layer.js"></script>
<script type="text/javascript" src="_ADMIN/static/h-ui/js/H-ui.min.js"></script> 
<script type="text/javascript" src="_ADMIN/static/h-ui.admin/js/H-ui.admin.js"></script> <!--/_footer 作为公共模版分离出去-->

<!--请在下方写此页面业务相关的脚本-->
<script type="text/javascript" src="_ADMIN/lib/My97DatePicker/4.8/WdatePicker.js"></script>
<script type="text/javascript" src="_ADMIN/lib/jquery.validation/1.14.0/jquery.validate.js"></script> 
<script type="text/javascript" src="_ADMIN/lib/jquery.validation/1.14.0/validate-methods.js"></script> 
<script type="text/javascript" src="_ADMIN/lib/jquery.validation/1.14.0/messages_zh.js"></script>
<script type="text/javascript" src="_ADMIN/lib/webuploader/0.1.5/webuploader.min.js"></script> 
<script type="text/javascript" src="_ADMIN/lib/ueditor/1.4.3/ueditor.config.js"></script>
<script type="text/javascript" src="_ADMIN/lib/ueditor/1.4.3/ueditor.all.min.js"> </script>
<script type="text/javascript" src="_ADMIN/lib/ueditor/1.4.3/lang/zh-cn/zh-cn.js"></script>
<script type="text/javascript">
$(function(){
	$('.skin-minimal input').iCheck({
		checkboxClass: 'icheckbox-blue',
		radioClass: 'iradio-blue',
		increaseArea: '20%'
	})});

//控制显示与隐藏
$(document).ready(function(){
    $(".field").change(function(){
        if($(this).val()=="增值税专用发票"){
        $(".field2").css("display","none");

        }else{
            $(".field2").css("display","");
        }});}
        );
</script>
</body>
</html>