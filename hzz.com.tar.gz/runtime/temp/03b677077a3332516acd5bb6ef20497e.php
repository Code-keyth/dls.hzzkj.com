<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:59:"/home/wwwroot/hzz.com/application/admin/view/index/off.html";i:1508323339;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>、
    <script type="text/javascript">
        var index = parent.layer.getFrameIndex(window.name);
        parent.layer.close(index);
    </script>
</head>



</html>