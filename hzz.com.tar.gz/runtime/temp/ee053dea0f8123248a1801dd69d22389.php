<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"/home/wwwroot/hzz.com/application/index/view/admin/article_list.html";i:1507978676;}*/ ?>
﻿<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit|ie-comp|ie-stand">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
	<meta http-equiv="Cache-Control" content="no-siteapp" />

	<!--[if lt IE 9]>
	<script type="text/javascript" src="_ADMIN/lib/html5shiv.js"></script>
	<script type="text/javas	cript" src="_ADMIN/lib/respond.min.js"></script>
	<![endif]-->
	<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui/css/H-ui.min.css" />
	<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/css/H-ui.admin.css" />
	<link rel="stylesheet" type="text/css" href="_ADMIN/lib/Hui-iconfont/1.0.8/iconfont.css" />
	<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/skin/default/skin.css" id="skin" />
	<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/css/style.css" />
	<!--[if IE 6]>
	<script type="text/javascript" src="_ADMIN/lib/DD_belatedPNG_0.0.8a-min.js" ></script>
	<script>DD_belatedPNG.fix('*');</script>
	<![endif]-->
	<title>资讯列表</title>
</head>
<body>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span> 资讯管理 <span class="c-gray en">&gt;</span> 资讯列表 <a class="btn btn-success radius r" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a></nav>
<div class="page-container" style="padding-top: 0;">
		<div class="mt-20">
		<table class="table table-border table-bordered table-bg table-hover table-sort table-responsive">
			<thead>
			<tr class="text-c">
				<th width="25"><input type="checkbox" name="" value=""></th>
				<th width="80">ID</th>
				<th>标题</th>
				<th width="80">分类</th>
				<th width="80">来源</th>
				<th width="120">更新时间</th>
				<th width="75">浏览次数</th>


			</tr>
			</thead>
			<tbody>
			<?php if(is_array($articles) || $articles instanceof \think\Collection || $articles instanceof \think\Paginator): $i = 0; $__LIST__ = $articles;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$article): $mod = ($i % 2 );++$i;?>
			<tr class="text-c">
				<td><input type="checkbox" value="<?php echo $article->getdata('id'); ?>" name="id"></td>
				<td><?php echo $key+1; ?></td>
				<td class="text-l"><u style="cursor:pointer" class="text-primary" title="查看"><a  href=<?php echo url('article_zhang'); ?>?id=<?php echo $article->getdata('id'); ?>"><?php echo $article->getdata('title'); ?></a></u></td>
				<td><?php echo $article->getdata('type'); ?></td>
				<td><?php echo $article->getdata('author'); ?></td>
				<td><?php echo $article->updata_time; ?></td>
				<td><?php echo $article->getdata('click'); ?></td>
			</tr>
			<?php endforeach; endif; else: echo "" ;endif; ?>
			</tbody>
		</table>
	</div>
</div>
<!--_footer 作为公共模版分离出去-->
<script type="text/javascript" src="_ADMIN/lib/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="_ADMIN/lib/layer/2.4/layer.js"></script>
<script type="text/javascript" src="_ADMIN/static/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="_ADMIN/static/h-ui.admin/js/H-ui.admin.js"></script> <!--/_footer 作为公共模版分离出去-->

<!--请在下方写此页面业务相关的脚本-->
<script type="text/javascript" src="_ADMIN/lib/My97DatePicker/4.8/WdatePicker.js"></script>
<script type="text/javascript" src="_ADMIN/lib/datatables/1.10.0/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="_ADMIN/lib/laypage/1.2/laypage.js"></script>
<script type="text/javascript">
    $('.table-sort').dataTable({
        //"aaSorting": [[ 1, "desc" ]],//默认第几个排序

        /*"aoColumnDefs": [
           {"bVisible": false, "aTargets": [2]}, //控制列的隐藏显示
            {"orderable":false,"aTargets":[1,6]}// 不参与排序的列
        ]*/
    });








</script>
</body>
</html>