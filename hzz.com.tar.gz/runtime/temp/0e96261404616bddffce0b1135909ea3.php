<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:64:"/home/wwwroot/hzz.com/application/index/view/login/register.html";i:1508726806;}*/ ?>
<!--_meta 作为公共模版分离出去-->
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="Bookmark" href="/favicon.ico" >
    <link rel="Shortcut Icon" href="/favicon.ico" />
    <!--[if lt IE 9]>
    <script type="text/javascript" src="_ADMIN/lib/html5shiv.js"></script>
    <script type="text/javascript" src="_ADMIN/lib/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui/css/H-ui.min.css" />
    <link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/css/H-ui.admin.css" />
    <link rel="stylesheet" type="text/css" href="_ADMIN/lib/Hui-iconfont/1.0.8/iconfont.css" />
    <link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/skin/default/skin.css" id="skin" />
    <link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/css/style.css" />
    <!--[if IE 6]>
    <script type="text/javascript" src="_ADMIN/lib/DD_belatedPNG_0.0.8a-min.js" ></script>
    <script>DD_belatedPNG.fix('*');</script>
    <![endif]-->
    <style>
        .form-control{
            height: 34px;
            width: 95%;
            float: left;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;}
    </style>
    <!--作为城市选择添加的-->
    <!--/meta 作为公共模版分离出去-->

    <title>添加用户 - H-ui.admin v3.1</title>
    <meta name="keywords" content="H-ui.admin v3.1,H-ui网站后台模版,后台模版下载,后台管理系统模版,HTML后台模版下载">
    <meta name="description" content="H-ui.admin v3.1，是一款由国人开发的轻量级扁平化网站后台模板，完全免费开源的网站后台管理系统模版，适合中小型CMS后台系统。">
</head>
<body>
<div style="width: 700px;margin: 0 auto;">
    <div class="text-c">注册</div>
<article class="page-container">
    <form action="<?php echo url('register_c'); ?>" method="post" class="form form-horizontal" id="form-member-add">
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>用户名：</label>
            <div class="formControls col-xs-5 col-sm-5">
                <input type="text" class="input-text addfrom  addname" value="" placeholder="" id="username" name="username" >
            </div>
            <div class="col-xs-3 col-xs-4 addname-wenzi">请使用4-16个字母和数字的组合 </div>
        </div>



        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>手机：</label>
            <div class="formControls col-xs-5 col-sm-5">
                <input type="text"  class="input-text addphone" value=""  placeholder="" id="mobile" name="mobile">
            </div>
            <div class="col-xs-3 col-xs-4 addname-phone"> * 请输入正确的手机号 </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>邮箱：</label>
            <div class="formControls col-xs-5 col-sm-5">
                <input type="text" value=""  class="input-text addemail" placeholder="@" name="email" id="email">
            </div>
            <div class="col-xs-3 col-xs-4  addname-addmail"> * 请输入正确的邮箱 </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>性别：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <select name="sex" class="select">
                    <option value="0">男</option>
                    <option value="1">女</option>
                </select>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>新密码：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="password" class="input-text" autocomplete="off" placeholder="不修改请留空" name="password" id="password">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>确认密码：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="password" class="input-text" autocomplete="off" placeholder="不修改请留空" name="newpassword2" id="new-password2">
            </div>
        </div>


        <div id="distpicker5" class="row cl">
            <label class="form-label col-xs-4 col-sm-3">所在城市：</label>
            <div class="formControls col-xs-8 col-sm-9" style="text-align: justify;">
                <div class="form-group col-xs-4">
                    <label class="sr-only" for="province10">Province</label>
                    <select name="province" value="" class="form-control" id="province10"></select>
                </div>
                <div class="form-group col-xs-4">
                    <label class="sr-only" for="city10">City</label>
                    <select name="city" value="" class="form-control" id="city10"></select>
                </div>
                <div class="form-group col-xs-4">
                    <label class="sr-only" for="district10">District</label>
                    <select name="district" value="" class="form-control" id="district10"></select>
                </div>


            </div>

        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red"></span>详细地址：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" class="input-text" value="" placeholder="" id="" name="street">
            </div>
        </div>
        <div class="row cl">
            <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
                <input class="btn btn-primary radius" type="submit" value="&nbsp;&nbsp;提交&nbsp;&nbsp;">
            </div>
        </div>
    </form>
    <![endif]-->

</article>
</div>
<!--_footer 作为公共模版分离出去-->
<script type="text/javascript" src="_ADMIN/lib/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript"  src="_ADMIN/js/biaodan.js"></script>
<script type="text/javascript" src="_ADMIN/lib/layer/2.4/layer.js"></script>
<script type="text/javascript" src="_ADMIN/static/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="_ADMIN/static/h-ui.admin/js/H-ui.admin.js"></script> <!--/_footer 作为公共模版分离出去-->

<!--请在下方写此页面业务相关的脚本-->
<script type="text/javascript" src="_ADMIN/lib/My97DatePicker/4.8/WdatePicker.js"></script>
<script type="text/javascript" src="_ADMIN/lib/jquery.validation/1.14.0/jquery.validate.js"></script>
<script type="text/javascript" src="_ADMIN/lib/jquery.validation/1.14.0/validate-methods.js"></script>
<script type="text/javascript" src="_ADMIN/lib/jquery.validation/1.14.0/messages_zh.js"></script>
<script type="text/javascript">
    $(function(){
        $('.skin-minimal input').iCheck({
            checkboxClass: 'icheckbox-blue',
            radioClass: 'iradio-blue',
            increaseArea: '20%'
        });
        $("#form-member-add").validate({
            rules:{
                username:{
                    required:true,
                    minlength:2,
                    maxlength:16
                },
                sex:{
                    required:true,
                },
                mobile:{
                    required:true,
                    isMobile:true,
                },
                email:{
                    required:true,
                    email:true,
                },
                uploadfile:{
                    required:true,
                },

            }
        });
    });

</script>
<!--/请在上方写此页面业务相关的脚本-->


<!--省市联动插件-->

<script src="_ADMIN/js/bootstrap.min.js"></script>
<script src="_ADMIN/js/distpicker.data.js"></script>
<script src="_ADMIN/js/distpicker.js"></script>
<script src="_ADMIN/js/main.js"></script>

<!--省市联动插件-->




</body>
</html>