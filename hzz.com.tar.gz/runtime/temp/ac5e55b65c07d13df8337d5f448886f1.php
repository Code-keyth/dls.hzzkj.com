<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:61:"/home/wwwroot/hzz.com/application/index/view/index/index.html";i:1508725713;s:60:"/home/wwwroot/hzz.com/application/index/view/index/head.html";i:1508725965;s:62:"/home/wwwroot/hzz.com/application/index/view/index/footer.html";i:1508666586;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>黑珍珠官网</title>

    <!-- Bootstrap -->
    <link href="_INDEX/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="_INDEX/style/index.css">
    <link rel="stylesheet" href="_INDEX/style/xunizhuji.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>

    <![endif]-->

    <script src="_INDEX/style/addnav.js"></script>
</head>
<body>



<div class="nav-banner col-md-12 col-sm-12  " style="z-index:66666; min-width: 1200px;">

    <div class="col-xs-3" style="display: inline-block;">
        <img src="_INDEX/images/logo.png" width="" alt="">

    </div>
    <div class="col-xs-9 " style="white-space: normal;">
        <div class=" col-xs-2 col-xs-offset-1 nav-qyjz nav-list-1 addhover">
            <a href="#" class="nda ">企业建站</a>
        </div>
        <div class=" col-xs-2 nav-list-2 addhover">
            <a href="#" class="nda ">软件开发</a>
        </div>

        <div class=" col-xs-2  nav-list-4 addhover">
            <a href="#" class="nda ">营销推广</a>
        </div>
        <div class=" col-xs-2  nav-list-5 addhover">
            <a href="#" class="nda ">渠道代理</a>
        </div>
        <div class=" col-xs-2  nav-list-6 addhover">
            <a href="#" class="nda ">联系我们</a>
        </div>

    </div>

    <div class="col-xs-10 col-xs-offset-2" id="nav-list-1" style=" ">
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">企业建站</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">定制网站</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">网上开店</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">微信分销</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">建站案例</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">微信小程序</a>
        </div>

    </div>

    <div class="col-xs-10 col-xs-offset-2" id="nav-list-2" style=" ">
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">中小企业云</a>
        </div>
        <div class="col-xs-3 addhover" style="">
            <a href="#" class="nda">数据开放平台</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">IT服务众包</a>
        </div>
        <div class="col-xs-3 addhover" style="">
            <a href="#" class="nda">跨境贸易服务</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">协同制造</a>
        </div>


    </div>
    <div class="col-xs-10 col-xs-offset-2  " id="nav-list-4" style=" ">
        <div class="col-xs-3  col-xs-offset-1 addhover" style="">
            <a href="#" class="nda">SEO优化</a>
        </div>
        <div class="col-xs-3 addhover" style="">
            <a href="#" class="nda">微信营销</a>
        </div>
        <div class="col-xs-3 addhover" style="">
            <a href="#" class="nda">基础口碑服务</a>
        </div>
    </div>



</div>
<script src="_INDEX/style/addnav.js"></script>

<div class="col-xs-12 col-sm-12 col-md-12 banner">
    <!--<img src="_INDEX/images/banner.png" alt="" width="100%" height="100%" >-->
    <div class="col-xs-12 col-sm-12 col-md-12 banner-word ">
        <h1>"互联网+" 领域开拓者</h1>
        <p class="font-light p1">专注于网络设计体验 , 专业与互联网解决方案</p>
        <p class="p2">超10000用户的放心选择</p>
        <p class="begin">开启你的互联网之旅</p>
        <div class="col-md-10 col-md-offset-1 add-icon max-display">
            <div class="row">
                <div class="col-sm-2 col-md-2 banner-icon ">
                    <div class="thumbnail">
                        <div class="banner-icon-top">
                            <img src="_INDEX/images/banner-icon1.png" alt="...">
                        </div>

                        <div class="caption">
                            <h3>企业建站</h3>
                        </div>
                        <span class="icon-geli"></span>
                    </div>
                </div>
                <div class="col-sm-2 col-md-2 banner-icon ">
                    <div class="thumbnail">
                        <div class="banner-icon-top">
                            <img src="_INDEX/images/banner-icon2.png" alt="...">
                        </div>

                        <div class="caption">
                            <h3>软件开发</h3>
                        </div>
                        <span class="icon-geli"></span>
                    </div>
                </div>
                <div class="col-sm-2 col-md-2 banner-icon ">
                    <div class="thumbnail">
                        <div class="banner-icon-top">
                            <img src="_INDEX/images/banner-icon3.png" alt="...">
                        </div>

                        <div class="caption">
                            <h3>虚拟主机</h3>
                        </div>
                        <span class="icon-geli"></span>
                    </div>
                </div>
                <div class="col-sm-2 col-md-2 banner-icon ">
                    <div class="thumbnail">
                        <div class="banner-icon-top">
                            <img src="_INDEX/images/banner-icon4.png" alt="...">
                        </div>

                        <div class="caption">
                            <h3>营销推广</h3>
                        </div>
                        <span class="icon-geli"></span>
                    </div>
                </div>
                <div class="col-sm-2 col-md-2 banner-icon ">
                    <div class="thumbnail">
                        <div class="banner-icon-top">
                            <img src="_INDEX/images/banner-icon5.png" alt="...">
                        </div>

                        <div class="caption">
                            <h3>渠道代理</h3>
                        </div>
                        <span class="icon-geli"></span>
                    </div>
                </div>
                <div class="col-sm-2 col-md-2 banner-icon ">
                    <div class="thumbnail">
                        <div class="banner-icon-top">
                            <img src="_INDEX/images/banner-icon6.png" alt="...">
                        </div>

                        <div class="caption">
                            <h3>联系我们</h3>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>


</div>


<div class=" col-xs-12 col-sm-12 col-md-12  slide1 ">
    <h3 class=" slide-h qiyeanli">
        企业案例
    </h3>

    <div class="col-md-12 ">
        <div class="row max-display-991">
            <div class="col-sm-offset-1 col-sm-2 col-md-offset-1 col-md-2 slide-thumbnail-father" style="t">
                <div class="thumbnail slide-thumbnail">
                    <div class="caption">
                        <p class="slide1-p" style="text-align: center;">建站案例</p>
                    </div>
                    <img src="_INDEX/images/slide-jz.png" width="100%" class="slide-img" alt="...">
                    <div class="slide-more">
                        <a href="#">点击查看 <span></span> </a>
                    </div>

                </div>
            </div>

            <div class="col-sm-2  col-md-2 slide-thumbnail-father slide-thumbnail-father-l " >
                <div class="thumbnail slide-thumbnail" >
                    <div class="caption">
                        <p class="slide1-p">商城案例</p>
                    </div>
                    <img src="_INDEX/images/slide1-sc.png" width="100%" class="slide-img" alt="...">
                    <div class="slide-more">
                        <a href="#">点击查看 <span></span> </a>
                    </div>

                </div>
            </div>
            <div class="col-sm-2 col-md-2 slide-thumbnail-father">
                <div class="thumbnail slide-thumbnail">
                    <div class="caption">
                        <p class="slide1-p">系统案例</p>
                    </div>
                    <img src="_INDEX/images/slide-xt.png" width="100%" class="slide-img" alt="...">
                    <div class="slide-more">
                        <a href="#">点击查看 <span></span> </a>
                    </div>

                </div>
            </div>
            <div class="col-sm-2  col-md-2 slide-thumbnail-father slide-thumbnail-father-r" >
                <div class="thumbnail slide-thumbnail">
                    <div class="caption">
                        <p class="slide1-p">APP案例</p>
                    </div>
                    <img src="_INDEX/images/slide-app.png" width="100%" class="slide-img" alt="...">
                    <div class="slide-more">
                        <a href="#">点击查看 <span></span> </a>
                    </div>

                </div>
            </div>
            <div class="col-sm-2  col-md-2 slide-thumbnail-father" style="">
                <div class="thumbnail slide-thumbnail">
                    <div class="caption">
                        <p class="slide1-p" style="text-align: center;">小程序案例</p>
                    </div>
                    <img src="_INDEX/images/slide-xcx.png" width="100%" class="slide-img" alt="...">
                    <div class="slide-more">
                        <a href="#">点击查看 <span></span> </a>
                    </div>

                </div>
            </div>

        </div>


        <div class="row display-991">

            <div class="col-xs-10 col-xs-offset-1 anli-icon-top">
                <div class="col-xs-10 anli-icon anli-icon-1">
                    <p>官网设计</p>
                    <p>BRAND WEBSITE</p>

                </div>

            </div>
            <div class="col-xs-10 col-xs-offset-1 anli-icon-top">
                <div class="col-xs-10 anli-icon anli-icon-2">
                    <p>商城案例</p>
                    <p>MALL CASE
                    </p>

                </div>

            </div>
            <div class="col-xs-10 col-xs-offset-1 anli-icon-top">
                <div class="col-xs-10 anli-icon anli-icon-3">
                    <p>系统案例</p>
                    <p>SYSTEM CASE
                    </p>

                </div>

            </div>
            <div class="col-xs-10 col-xs-offset-1 anli-icon-top">
                <div class="col-xs-10 anli-icon anli-icon-4">
                    <p>APP案例</p>
                    <p>APP CASE</p>

                </div>

            </div>
            <div class="col-xs-10 col-xs-offset-1 anli-icon-top anli-icon-bottom">
                <div class="col-xs-10 anli-icon anli-icon-5">
                    <p>小程序案例</p>
                    <p>SMALL ROUTINE CASE </p>

                </div>

            </div>


        </div>
    </div>
</div>


<div class="col-xs-12 col-sm-12 col-md-12  slide2">

    <h3 class=" slide-h hezuo ">
        长期合作客户
    </h3>
    <div class="col-xs-12 col-sm-12 col-md-10 col-md-offset-1  ">
        <div class="row ">
            <div class="col-xs-6 col-md-3 thumbnail-aback-top ">
                <a href="#" class="thumbnail   thumbnail-aback">
                    <img src="_INDEX/images/index-pnp.jpg" width="100%" height="100%" alt="...">
                    <div class="thumbnail-aback-son">
<p>
    Plug and Play
</p>
                    </div>

                </a>

            </div>
            <div class="col-xs-6 col-md-3 thumbnail-aback-top ">
                <a href="#" class="thumbnail   thumbnail-aback">
                    <img src="_INDEX/images/index-sias.jpg" width="100%" height="100%" alt="...">
                    <div class="thumbnail-aback-son"></div>

                </a>

            </div>
            <div class="col-xs-6 col-md-3 thumbnail-aback-top ">
                <a href="#" class="thumbnail   thumbnail-aback">
                    <img src="_INDEX/images/hezuo.png" width="100%" height="100%" alt="...">
                    <div class="thumbnail-aback-son"></div>

                </a>

            </div>
            <div class="col-xs-6 col-md-3 thumbnail-aback-top ">
                <a href="#" class="thumbnail   thumbnail-aback">
                    <img src="_INDEX/images/hezuo.png" width="100%" height="100%" alt="...">
                    <div class="thumbnail-aback-son"></div>

                </a>

            </div>
        </div>


        <div class="row   max-display">
            <div class="col-xs-6 col-md-3 thumbnail-aback-top ">
                <a href="#" class="thumbnail   thumbnail-aback">
                    <img src="_INDEX/images/hezuo.png" width="100%" height="100%" alt="...">
                    <div class="thumbnail-aback-son"></div>

                </a>

            </div>
            <div class="col-xs-6 col-md-3 thumbnail-aback-top ">
                <a href="#" class="thumbnail   thumbnail-aback">
                    <img src="_INDEX/images/hezuo.png" width="100%" height="100%" alt="...">
                    <div class="thumbnail-aback-son"></div>

                </a>

            </div>
            <div class="col-xs-6 col-md-3 thumbnail-aback-top ">
                <a href="#" class="thumbnail   thumbnail-aback">
                    <img src="_INDEX/images/hezuo.png" width="100%" height="100%" alt="...">
                    <div class="thumbnail-aback-son"></div>

                </a>

            </div>
            <div class="col-xs-6 col-md-3 thumbnail-aback-top ">
                <a href="#" class="thumbnail   thumbnail-aback">
                    <img src="_INDEX/images/hezuo.png" width="100%" height="100%" alt="...">
                    <div class="thumbnail-aback-son"></div>

                </a>

            </div>

        </div>


    </div>


</div>

<div class="col-xs-12 col-sm-12 col-md-12  slide3">

    <h3 class=" slide-h hezuo ">
        我们的优势
    </h3>


    <!--测试区域-->

    <div id="carousel-example-generic" class="carousel slide display" data-ride="carousel" style="height: 320px;">
        <!-- Indicators -->
        <!--<ol class="carousel-indicators">-->
        <!--<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>-->
        <!--<li data-target="#carousel-example-generic" data-slide-to="1"></li>-->
        <!--<li data-target="#carousel-example-generic" data-slide-to="2"></li>-->
        <!--<li data-target="#carousel-example-generic" data-slide-to="3"></li>-->
        <!--<li data-target="#carousel-example-generic" data-slide-to="4"></li>-->
        <!--<li data-target="#carousel-example-generic" data-slide-to="5"></li>-->
        <!--</ol>-->

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <div class="item active">
                <div class=" col-xs-12 col-sm-4 col-md-4">
                    <div class="thumbnail slide-thumbnail3">
                        <img src="_INDEX/images/youshi-1.png" alt="...">
                        <div class="caption">
                            <h3>黑珍珠十年金牌品质保证</h3>
                            <p class="slide-p1">10年行业经验 <br> 300人服务经营团队百万客户信赖选择</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class=" col-xs-12 col-sm-4 col-md-4">
                    <div class="thumbnail slide-thumbnail3">
                        <img src="_INDEX/images/youshi-2.png" alt="...">
                        <div class="caption">
                            <h3>拥有顶尖核心技术人才</h3>
                            <p class="slide-p1">黑珍珠业务范围涵盖各技术语言支持 <br> 团队技术达一流标准</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class=" col-xs-12 col-sm-4 col-md-4">
                    <div class="thumbnail slide-thumbnail3">
                        <img src="_INDEX/images/youshi-3.png" alt="...">
                        <div class="caption">
                            <h3>全面提升网站营销价值</h3>
                            <p class="slide-p1">通过搜索引擎及基础口碑建设 <br> 助力中小企业网站引流</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class=" col-xs-12 col-sm-4 col-md-4">
                    <div class="thumbnail slide-thumbnail3">
                        <img src="_INDEX/images/youshi-4.png" alt="...">
                        <div class="caption">
                            <h3>覆盖全国本地化服务</h3>
                            <p class="slide-p1">团队业务支持目前国内覆盖率达58个县市 <br></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class=" col-xs-12 col-sm-4 col-md-4">
                    <div class="thumbnail slide-thumbnail3">
                        <img src="_INDEX/images/youshi-5.png" alt="...">
                        <div class="caption">
                            <h3>打造合作共赢互联网生态理念</h3>
                            <p class="slide-p1">开展代理渠道 <br> 让每一个人都都可拥有黑珍珠的服务资源</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class=" col-xs-12 col-sm-4 col-md-4">
                    <div class="thumbnail slide-thumbnail3">
                        <img src="_INDEX/images/youshi-6.png" alt="...">
                        <div class="caption">
                            <h3>7*24小时专家支持服务</h3>
                            <p class="slide-p1">365天快速响应，国粤英三语，400电话、QQ、 微信、在线客服等多渠道售后支持</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>


    <!--测试区域-->

    <div class=" col-sm-12 col-md-10 col-md-offset-1 max-display ">
        <div class="row youshi">

            <div class=" col-xs-2 col-sm-4 col-md-4">
                <div class="thumbnail slide-thumbnail3">
                    <img src="_INDEX/images/youshi-1.png" alt="...">
                    <div class="caption">
                        <h3>黑珍珠十年金牌品质保证</h3>
                        <p class="slide-p1">10年行业经验，300人服务经营团队百万客户信赖选择</p>
                    </div>
                </div>
            </div>
            <div class="col-xs-2 col-sm-4 col-md-4">
                <div class="thumbnail slide-thumbnail3">
                    <img src="_INDEX/images/youshi-2.png" alt="...">
                    <div class="caption">
                        <h3>拥有顶尖核心技术人才</h3>
                        <p class="slide-p1">黑珍珠业务范围涵盖各技术语言支持，团队技术达一流标准</p>
                    </div>
                </div>
            </div>
            <div class=" col-xs-2 col-sm-4 col-md-4">
                <div class="thumbnail slide-thumbnail3">
                    <img src="_INDEX/images/youshi-3.png" alt="...">
                    <div class="caption">
                        <h3>全面提升网站营销价值</h3>
                        <p class="slide-p1">通过搜索引擎及基础口碑建设，助力中小企业网站引流</p>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12"></div>
            <div class=" col-xs-2 col-sm-4 col-md-4">
                <div class="thumbnail slide-thumbnail3">
                    <img src="_INDEX/images/youshi-4.png" alt="...">
                    <div class="caption">
                        <h3>覆盖全国本地化服务</h3>
                        <p class="slide-p1">团队业务支持目前国内覆盖率达58个县市</p>
                    </div>
                </div>
            </div>
            <div class="col-xs-2 col-sm-4 col-md-4">
                <div class="thumbnail slide-thumbnail3">
                    <img src="_INDEX/images/youshi-5.png" alt="...">
                    <div class="caption">
                        <h3>打造合作共赢互联网生态理念</h3>
                        <p class="slide-p1">开展代理渠道，让每一个人都都可拥有黑珍珠的服务资源</p>
                    </div>
                </div>
            </div>
            <div class=" col-xs-2 col-sm-4 col-md-4">
                <div class="thumbnail slide-thumbnail3">
                    <img src="_INDEX/images/youshi-6.png" alt="...">
                    <div class="caption">
                        <h3>7*24小时专家支持服务</h3>
                        <p class="slide-p1">365天快速响应，国粤英三语，400电话、QQ、 微信、在线客服等多渠道售后支持</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>



<div class="col-xs-12 col-sm-12 col-md-12  slide4">

    <div class="col-md-10 col-md-offset-1">
        <div class="col-md-3  col-sm-12 col-xs-12" style="padding-left: 0;">
            <h3 class="slide4-zb">准备开展业务？</h3>
        </div>
        <div class="col-md-6">


            <div class="col-md-5 col-md-offset-1  col-sm-6 col-xs-6">
                <h4 class="slide4-but slide4-but1">
                    <a href="#">立即创建网站</a>
                </h4>
            </div>
            <div class="col-md-5   col-sm-6 col-xs-6">
                <h4 class="slide4-but slide4-but2">
                    <a href="#">成为渠道商</a>
                </h4>
            </div>

        </div>

        <div class="col-md-3   col-sm-6 col-xs-6  slide4-tel" style="text-align: right;margin-top: 30px;">或者拨打:
            0371-60297655
            <img src="_INDEX/images/7-24.png" width="100%" alt="">
        </div>
    </div>


    <!--slide4结束-->
</div>
<!--slide4结束-->

<div class="col-md-12 col-sm-12 col-xs-12 slide5">
    <div class="col-md-offset-1 col-md-10 col-xs-12 col-sm-12 slide5-top">


        <div class="col-md-3 col-sm-6 slide5-767">
            <p class="slide5-tit">联系我们</p>
            <p>河南·郑州 金水区创业园北林路16号</p>
            <p>联系电话：0371-60297655</p>
            <p>Email：n89@163.com</p>
            <p>邮编：450000</p>
            <img src="_INDEX/images/erweima.png" alt="二维码">
            <p class="max-display">
                <!-- JiaThis Button BEGIN -->
            <div class="jiathis_style_24x24 max-display">
                <a class="jiathis_button_weixin"></a>
                <a class="jiathis_button_tsina"></a>
                <a class="jiathis_button_qzone"></a>
                <a class="jiathis_button_tqq"></a>
                <a href="" class="jiathis jiathis_txt jtico jtico_jiathis"
                   target="_blank"></a>

            </div>
            <script type="text/javascript" src="http://v3.jiathis.com/code/jia.js" charset="utf-8"></script>
            <!-- JiaThis Button END -->
            </p>
        </div>
        <div class="col-md-3 col-sm-6 max-display">
            <p class="slide5-tit">"互联网+" 新闻中心</p>
            <p class="slide5-tit-2">加快HTML5开发可视化编辑器 </p>
            <p>随着HTML5游戏《围住神经猫》爆红网络， 越来越多的游戏开发者把目光投向HTML5领域。但是HTML5游戏...</p>
            <p class="slide5-tit-2">HTML5 Canvas中绘制矩形实例教程</p>
            <p>本文翻译自Steve Fulton Jeff Fulton HTML5Canvas, Chapter 2, The Basic RectangleShape. 让我们来看一下...</p>

        </div>
        <div class="col-sm-12 display-991">

        </div>
        <div class="col-md-3 col-sm-6 max-display">
            <p class="slide5-tit">产品与服务</p>

            <div class="col-md-6 col-sm-6 cpfw-tit">
                <p class="cpfw cpfw-a">
                    <a href="#">企业建站</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">定制网站</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">小程序开发</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">微信分销</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">网上开店</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">软件及系统开发服务</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">微信营销</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">SEO优化</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">基础口碑服务</a>
                </p>

            </div>

            <div class="col-md-6 col-sm-6 cpfw-tit" style="text-align: right;padding-right: 15px;">
                <p class="cpfw cpfw-a">
                    <a href="#">代理政策</a>
                </p>

                <p class="cpfw cpfw-a">
                    <a href="#">代理流程</a>
                </p>

                <p class="cpfw cpfw-a">
                    <a href="#">代理注册</a>
                </p>

                <p class="cpfw cpfw-a">
                    <a href="#">代理咨询</a>
                </p>


            </div>
        </div>
        <div class="col-md-3 col-sm-6 max-display">
            <p class="slide5-tit">发送留言</p>
            <form>
                <div class="form-group">

                    <input type="name" class="form-control" id="exampleInputEmail1" placeholder="姓名">
                </div>
                <div class="form-group">

                    <input type="tel" class="form-control" id="exampleInputEmail1" placeholder="联系方式">
                </div>
                <div class="form-group">

                    <textarea class="form-control" rows="3" placeholder="留言内容"></textarea>
                </div>

                <button type="submit" class="btn btn-default btn-footer">提 交</button>
            </form>

        </div>


    </div>


</div>


<div class="col-md-12  col-xs-12 col-sm-12 footer-foot-top max-display-991">


    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-1 col-xs-12 footer-foot-body foot-body-1 max-display ">
        <a href="#">关于黑珍珠 |</a>
        <a href="#">联系我们 |</a>
        <a href="#">付款方式 |</a>
        <a href="#">网站备案 |</a>
        <a href="#">价格总览 |</a>
        <a href="#">帮助中心 |</a>
        <a href="#">诚聘英才 |</a>
        <a href="#">新闻中心 |</a>
        <a href="#">相关下载</a>
    </div>

    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-1 col-xs-12 footer-foot-body foot-body-2 max-display ">
        <a href="#">网站反馈 |</a>
        <a href="#">企业建站 |</a>
        <a href="#">软件开发 |</a>
        <a href="#">域名申请 |</a>
        <a href="#">虚拟主机 |</a>
        <a href="#">企业邮箱 |</a>
        <a href="#">营销推广 |</a>
        <a href="#">云主机 |</a>
        <a href="#">技术支持尽在黑珍珠</a>
    </div>

    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-1 col-xs-12 footer-foot-body foot-body-1 ">
        <p>© 2017黑珍珠科技备案号: <a href="#">豫ICP备 15011304-5号</a></p>
    </div>
</div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="_INDEX/js/bootstrap.min.js"></script>
</body>
</html>