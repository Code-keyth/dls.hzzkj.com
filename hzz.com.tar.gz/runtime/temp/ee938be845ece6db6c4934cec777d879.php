<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:63:"/home/wwwroot/hzz.com/application/index/view/index/station.html";i:1508726001;s:60:"/home/wwwroot/hzz.com/application/index/view/index/head.html";i:1508725965;s:62:"/home/wwwroot/hzz.com/application/index/view/index/footer.html";i:1508666586;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>企业建站-企业建站</title>

    <!-- Bootstrap -->
    <link href="_INDEX/css/bootstrap.min.css" rel="stylesheet">


    <link rel="stylesheet" href="_INDEX/style/index.css">
    <link rel="stylesheet" href="_INDEX/style/xunizhuji.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>

    <![endif]-->

</head>
<body>



<div class="nav-banner col-md-12 col-sm-12  " style="z-index:66666; min-width: 1200px;">

    <div class="col-xs-3" style="display: inline-block;">
        <img src="_INDEX/images/logo.png" width="" alt="">

    </div>
    <div class="col-xs-9 " style="white-space: normal;">
        <div class=" col-xs-2 col-xs-offset-1 nav-qyjz nav-list-1 addhover">
            <a href="#" class="nda ">企业建站</a>
        </div>
        <div class=" col-xs-2 nav-list-2 addhover">
            <a href="#" class="nda ">软件开发</a>
        </div>

        <div class=" col-xs-2  nav-list-4 addhover">
            <a href="#" class="nda ">营销推广</a>
        </div>
        <div class=" col-xs-2  nav-list-5 addhover">
            <a href="#" class="nda ">渠道代理</a>
        </div>
        <div class=" col-xs-2  nav-list-6 addhover">
            <a href="#" class="nda ">联系我们</a>
        </div>

    </div>

    <div class="col-xs-10 col-xs-offset-2" id="nav-list-1" style=" ">
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">企业建站</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">定制网站</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">网上开店</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">微信分销</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">建站案例</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">微信小程序</a>
        </div>

    </div>

    <div class="col-xs-10 col-xs-offset-2" id="nav-list-2" style=" ">
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">中小企业云</a>
        </div>
        <div class="col-xs-3 addhover" style="">
            <a href="#" class="nda">数据开放平台</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">IT服务众包</a>
        </div>
        <div class="col-xs-3 addhover" style="">
            <a href="#" class="nda">跨境贸易服务</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">协同制造</a>
        </div>


    </div>
    <div class="col-xs-10 col-xs-offset-2  " id="nav-list-4" style=" ">
        <div class="col-xs-3  col-xs-offset-1 addhover" style="">
            <a href="#" class="nda">SEO优化</a>
        </div>
        <div class="col-xs-3 addhover" style="">
            <a href="#" class="nda">微信营销</a>
        </div>
        <div class="col-xs-3 addhover" style="">
            <a href="#" class="nda">基础口碑服务</a>
        </div>
    </div>



</div>
<script src="_INDEX/style/addnav.js"></script>

<div class="col-xs-12 col-sm-12 col-md-12  qyjz-qyjz-banner">
    <!--<img src="_INDEX/images/banner.png" alt="" width="100%" height="100%" >-->
    <div class="col-xs-12 col-sm-12 col-md-12  col-lg-10 col-lg-offset-1 qyjz-qyjz-ban " style="text-align: center;">

        <div id="carousel-example-generic" class="carousel slide col-md-10 col-md-offset-1 col-lg-10 col-sm-12"
             data-ride="carousel" style="



">
            <!-- Indicators -->


            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox" style="">
                <div class="item active">
                    <div class="carousel-caption carousel-caption-qyjs-ban " style="">
                        <h3>企业展示</h3>
                        <p style="" class="qyjs-ban-p1"> 适合企业</p>
                        <p>企业展示型 发展期企业，初创期企业，企业官网。
                            <br>
                            以展示企业实力和品牌战略为主要方向。</p>

                        <p class=" qyjs-ban-p3 " style="">
                            <a href="#" class="nda" style="">查看更多原型</a>
                        </p>
                    </div>
                    <img src="_INDEX/images/qyjz-qyjz-banner-1.jpg" width="100%" height="100%" alt="...">

                </div>
                <div class="item ">
                    <div class="carousel-caption carousel-caption-qyjs-ban " style="">
                        <h3>企业展示</h3>
                        <p style="" class="qyjs-ban-p1"> 适合企业</p>
                        <p>企业展示型 发展期企业，初创期企业，企业官网。
                            <br>
                            以展示企业实力和品牌战略为主要方向。</p>

                        <p class=" qyjs-ban-p3 " style="">
                            <a href="#" class="nda" style="">查看更多原型</a>
                        </p>
                    </div>
                    <img src="_INDEX/images/qyjz-qyjz-banner-1.jpg" width="100%" height="100%" alt="...">

                </div>
                <div class="item ">
                    <div class="carousel-caption carousel-caption-qyjs-ban " style="">
                        <h3>企业展示</h3>
                        <p style="" class="qyjs-ban-p1"> 适合企业</p>
                        <p>企业展示型 发展期企业，初创期企业，企业官网。
                            <br>
                            以展示企业实力和品牌战略为主要方向。</p>

                        <p class=" qyjs-ban-p3 " style="">
                            <a href="#" class="nda" style="">查看更多原型</a>
                        </p>
                    </div>
                    <img src="_INDEX/images/qyjz-qyjz-banner-1.jpg" width="100%" height="100%" alt="...">

                </div>


            </div>

            <!-- Controls -->
            <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>

    </div>

</div>


<div class="col-md-12 col-sm-12 col-xs-12 qyjz-slide1 " style="">
    <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: center; color: #333;">
        <h3>您需要的是这样一个全网营销网站</h3>
        <p class="mac-p1">
            客户充分信任您
        </p>
        <p class="p-bottom">
            全新“分销加盟+三级返佣”模式体系 <br>
            无限发展下游，让您的分销商满天下
        </p>
    </div>
    <div class="col-md-10 col-md-offset-1 col-sm-12 col-xs-12">
        <div class="col-md-4 col-sm-4 col-xs-4" style="text-align: center;">
            <p class="mac-p1">
                销售网络快速扩张
            </p>
            <p class="p-bottom">
                强大视觉冲击力提升网站形象展示 <br>
                极具销售力的产品展示突出卖点，吸引眼球打动客户
            </p>

            <p class="mac-p1">
                超强电商管理引爆成交量
            </p>
            <p class="p-bottom">
                强大的商品管理，团购、秒杀等电商功能促进高销量 <br>
                方便快捷的购物车及支付方式促进成交、流量 <br>
                业绩统计分析尽在掌握中
            </p>
        </div>

        <div class="col-md-4 col-sm-4 col-xs-4" style="text-align: center;">

            <img src="_INDEX/images/qyjz-qyjz-mac.png" width="110%" alt="">


        </div>

        <div class="col-md-4 col-sm-4 col-xs-4" style="text-align: center;">
            <p class="mac-p1">
                实时互动沟通转化率高
            </p>
            <p class="p-bottom">
                方便的客服沟通工具，实时互动咨询 <br>
                快速提升询盘率和成交转化率，变流量为销量
            </p>

            <p class="mac-p1">
                强化维系客户，利润持续增长
            </p>
            <p class="p-bottom">
                客户管理、维系、关怀全方位，结合高效互动营销工具 <br>
                深度挖掘新老客户潜力价值，刺激客户持续消费
            </p>
        </div>


    </div>
    <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: center; color: #333;">

        <p class="mac-p1 mac-bottom">
            更多客户快速找到您
        </p>
        <p style="margin-bottom: 50px;">
            PC+手机端全网搜索引擎SEO优化 <br>
            提升网站排名引流量，更多客户找到您 <br>
            强大推广方式+超强营销工具，扩大客流量、订单量
        </p>
    </div>
</div>
<div class="col-md-12 col-sm-12 col-xs-12 qyjz-slide1 " style=" background: #ffffff;">
    <div class="col-md-10 col-md-offset-1  col-sm-12 col-xs-12" style="text-align: center; color: #333;">
        <h3>精品建站模板</h3>
        <p class="">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        </p>

        <div class="row ">
            <div class="col-xs-6 col-md-3">
                <a href="#" class="thumbnail qyjz-thumbnail" style="">
                    <img src="_INDEX/images/qyjz-jp1.png" width="100%" alt="...">
                </a>
            </div>

            <div class="col-xs-6 col-md-3">
                <a href="#" class="thumbnail qyjz-thumbnail" style="">
                    <img src="_INDEX/images/qyjz-jp1.png" width="100%" alt="...">
                </a>
            </div>
            <div class="col-xs-6 col-md-3">
                <a href="#" class="thumbnail qyjz-thumbnail" style="">
                    <img src="_INDEX/images/qyjz-jp1.png" width="100%" alt="...">
                </a>
            </div>
            <div class="col-xs-6 col-md-3">
                <a href="#" class="thumbnail qyjz-thumbnail" style="">
                    <img src="_INDEX/images/qyjz-jp1.png" width="100%" alt="...">
                </a>
            </div>

        </div>

    </div>
    <div class="col-md-10 col-md-offset-1 col-sm-12 col-xs-12">


    </div>
</div>

<div class="col-md-12 col-sm-12 col-xs-12 qyjz-slide1 qyjz-fly " style=" ">
    <div class="col-md-10 col-md-offset-1  col-sm-12 col-xs-12" style="text-align: center; color: #333;">
        <h3 class="fly-p fly-h">黑珍珠的更多服务</h3>
        <p class="">
            <img src="_INDEX/images/fly.png" alt="">
        </p>

        <div class="row ">
            <div class="col-xs-6 col-md-3" style="padding-bottom: 40px;">
                <h4 class="fly-h4">免费专业培训</h4>
                <p  class="fly-more-p">
                    每月建站、微信营销、电商等互联网
                </p>
            </div>
            <div class="col-xs-6 col-md-3" style="padding-bottom: 40px;">
                <h4 class="fly-h4">&nbsp;&nbsp;&nbsp;&nbsp;免费升级&nbsp;&nbsp;&nbsp;&nbsp;</h4>
                <p class="fly-more-p">
                    营销功能、插件持续每月更新开发升
                </p>
            </div>
            <div class="col-xs-6 col-md-3" style="padding-bottom: 40px;">
                <h4 class="fly-h4">七大核心优势</h4>
                <p  class="fly-more-p">
                    低成本、建站快、营销强。超高性价
                </p>
            </div>
            <div class="col-xs-6 col-md-3" style="padding-bottom: 40px;">
                <h4 class="fly-h4">7*24小时快速响应</h4>
                <p  class="fly-more-p">
                    企业电话、QQ、微信、在线等多渠
                </p>
            </div>

        </div>

    </div>
    <div class="col-md-10 col-md-offset-1 col-sm-12 col-xs-12">


    </div>
</div>


<!--footer范围-->

<div class="col-xs-12 col-sm-12 col-md-12  slide4">

    <div class="col-md-10 col-md-offset-1">
        <div class="col-md-3  col-sm-12 col-xs-12" style="padding-left: 0;">
            <h3 class="slide4-zb">准备开展业务？</h3>
        </div>
        <div class="col-md-6">


            <div class="col-md-5 col-md-offset-1  col-sm-6 col-xs-6">
                <h4 class="slide4-but slide4-but1">
                    <a href="#">立即创建网站</a>
                </h4>
            </div>
            <div class="col-md-5   col-sm-6 col-xs-6">
                <h4 class="slide4-but slide4-but2">
                    <a href="#">成为渠道商</a>
                </h4>
            </div>

        </div>

        <div class="col-md-3   col-sm-6 col-xs-6  slide4-tel" style="text-align: right;margin-top: 30px;">或者拨打:
            0371-60297655
            <img src="_INDEX/images/7-24.png" width="100%" alt="">
        </div>
    </div>


    <!--slide4结束-->
</div>
<!--slide4结束-->

<div class="col-md-12 col-sm-12 col-xs-12 slide5">
    <div class="col-md-offset-1 col-md-10 col-xs-12 col-sm-12 slide5-top">


        <div class="col-md-3 col-sm-6 slide5-767">
            <p class="slide5-tit">联系我们</p>
            <p>河南·郑州 金水区创业园北林路16号</p>
            <p>联系电话：0371-60297655</p>
            <p>Email：n89@163.com</p>
            <p>邮编：450000</p>
            <img src="_INDEX/images/erweima.png" alt="二维码">
            <p class="max-display">
                <!-- JiaThis Button BEGIN -->
            <div class="jiathis_style_24x24 max-display">
                <a class="jiathis_button_weixin"></a>
                <a class="jiathis_button_tsina"></a>
                <a class="jiathis_button_qzone"></a>
                <a class="jiathis_button_tqq"></a>
                <a href="" class="jiathis jiathis_txt jtico jtico_jiathis"
                   target="_blank"></a>

            </div>
            <script type="text/javascript" src="http://v3.jiathis.com/code/jia.js" charset="utf-8"></script>
            <!-- JiaThis Button END -->
            </p>
        </div>
        <div class="col-md-3 col-sm-6 max-display">
            <p class="slide5-tit">"互联网+" 新闻中心</p>
            <p class="slide5-tit-2">加快HTML5开发可视化编辑器 </p>
            <p>随着HTML5游戏《围住神经猫》爆红网络， 越来越多的游戏开发者把目光投向HTML5领域。但是HTML5游戏...</p>
            <p class="slide5-tit-2">HTML5 Canvas中绘制矩形实例教程</p>
            <p>本文翻译自Steve Fulton Jeff Fulton HTML5Canvas, Chapter 2, The Basic RectangleShape. 让我们来看一下...</p>

        </div>
        <div class="col-sm-12 display-991">

        </div>
        <div class="col-md-3 col-sm-6 max-display">
            <p class="slide5-tit">产品与服务</p>

            <div class="col-md-6 col-sm-6 cpfw-tit">
                <p class="cpfw cpfw-a">
                    <a href="#">企业建站</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">定制网站</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">小程序开发</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">微信分销</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">网上开店</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">软件及系统开发服务</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">微信营销</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">SEO优化</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">基础口碑服务</a>
                </p>

            </div>

            <div class="col-md-6 col-sm-6 cpfw-tit" style="text-align: right;padding-right: 15px;">
                <p class="cpfw cpfw-a">
                    <a href="#">代理政策</a>
                </p>

                <p class="cpfw cpfw-a">
                    <a href="#">代理流程</a>
                </p>

                <p class="cpfw cpfw-a">
                    <a href="#">代理注册</a>
                </p>

                <p class="cpfw cpfw-a">
                    <a href="#">代理咨询</a>
                </p>


            </div>
        </div>
        <div class="col-md-3 col-sm-6 max-display">
            <p class="slide5-tit">发送留言</p>
            <form>
                <div class="form-group">

                    <input type="name" class="form-control" id="exampleInputEmail1" placeholder="姓名">
                </div>
                <div class="form-group">

                    <input type="tel" class="form-control" id="exampleInputEmail1" placeholder="联系方式">
                </div>
                <div class="form-group">

                    <textarea class="form-control" rows="3" placeholder="留言内容"></textarea>
                </div>

                <button type="submit" class="btn btn-default btn-footer">提 交</button>
            </form>

        </div>


    </div>


</div>


<div class="col-md-12  col-xs-12 col-sm-12 footer-foot-top max-display-991">


    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-1 col-xs-12 footer-foot-body foot-body-1 max-display ">
        <a href="#">关于黑珍珠 |</a>
        <a href="#">联系我们 |</a>
        <a href="#">付款方式 |</a>
        <a href="#">网站备案 |</a>
        <a href="#">价格总览 |</a>
        <a href="#">帮助中心 |</a>
        <a href="#">诚聘英才 |</a>
        <a href="#">新闻中心 |</a>
        <a href="#">相关下载</a>
    </div>

    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-1 col-xs-12 footer-foot-body foot-body-2 max-display ">
        <a href="#">网站反馈 |</a>
        <a href="#">企业建站 |</a>
        <a href="#">软件开发 |</a>
        <a href="#">域名申请 |</a>
        <a href="#">虚拟主机 |</a>
        <a href="#">企业邮箱 |</a>
        <a href="#">营销推广 |</a>
        <a href="#">云主机 |</a>
        <a href="#">技术支持尽在黑珍珠</a>
    </div>

    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-1 col-xs-12 footer-foot-body foot-body-1 ">
        <p>© 2017黑珍珠科技备案号: <a href="#">豫ICP备 15011304-5号</a></p>
    </div>
</div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="_INDEX/js/bootstrap.min.js"></script>

</body>
</html>