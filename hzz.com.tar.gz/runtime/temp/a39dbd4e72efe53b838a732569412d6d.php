<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:66:"/home/wwwroot/hzz.com/application/index/view/index/customized.html";i:1508663482;s:60:"/home/wwwroot/hzz.com/application/index/view/index/head.html";i:1508665717;s:62:"/home/wwwroot/hzz.com/application/index/view/index/footer.html";i:1508666296;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>企业建站-网站定制</title>

    <!-- Bootstrap -->
    <link href="_INDEX/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="_INDEX/style/index.css">
    <link rel="stylesheet" href="_INDEX/style/xunizhuji.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>

<div class="nav-banner col-md-12 col-sm-12  " style="z-index:66666; min-width: 1200px;">

    <div class="col-xs-3" style="display: inline-block;">
        <img src="_INDEX/images/logo.png" width="" alt="">

    </div>
    <div class="col-xs-9 " style="white-space: normal;">
        <div class=" col-xs-2 col-xs-offset-1 nav-qyjz nav-list-1 addhover">
            <a href="#" class="nda ">企业建站</a>
        </div>
        <div class=" col-xs-2 nav-list-2 addhover">
            <a href="#" class="nda ">软件开发</a>
        </div>

        <div class=" col-xs-2  nav-list-4 addhover">
            <a href="#" class="nda ">营销推广</a>
        </div>
        <div class=" col-xs-2  nav-list-5 addhover">
            <a href="#" class="nda ">渠道代理</a>
        </div>
        <div class=" col-xs-2  nav-list-6 addhover">
            <a href="#" class="nda ">联系我们</a>
        </div>

    </div>

    <div class="col-xs-10 col-xs-offset-2" id="nav-list-1" style=" ">
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">企业建站</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">定制网站</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">网上开店</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">微信分销</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">建站案例</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">微信小程序</a>
        </div>

    </div>

    <div class="col-xs-10 col-xs-offset-2" id="nav-list-2" style=" ">
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">中小企业云</a>
        </div>
        <div class="col-xs-3 addhover" style="">
            <a href="#" class="nda">数据开放平台</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">IT服务众包</a>
        </div>
        <div class="col-xs-3 addhover" style="">
            <a href="#" class="nda">跨境贸易服务</a>
        </div>
        <div class="col-xs-2 addhover" style="">
            <a href="#" class="nda">协同制造</a>
        </div>


    </div>
    <div class="col-xs-10 col-xs-offset-2  " id="nav-list-4" style=" ">
        <div class="col-xs-3  col-xs-offset-1 addhover" style="">
            <a href="#" class="nda">SEO优化</a>
        </div>
        <div class="col-xs-3 addhover" style="">
            <a href="#" class="nda">微信营销</a>
        </div>
        <div class="col-xs-3 addhover" style="">
            <a href="#" class="nda">基础口碑服务</a>
        </div>
    </div>



</div>

<div class="col-xs-12 col-sm-12 col-md-12  wzdz-banner">
    <!--<img src="_INDEX/images/banner.png" alt="" width="100%" height="100%" >-->
    <div class="col-xs-12 col-sm-12 col-md-12 banner-word ">
        <h2>黑珍珠私人专属定制建站</h2>

        <p class="p2">定位设计+网站推广+后期运营=网站营销事半功倍 </p>
    </div>

</div>
<div class="col-xs-12 wzdz-slide1">
    <div class="col-xs-12 col-sm-12 col-md-10 col-md-offset-1  ">
        <div class="col-xs-12">
            <h2 class="c3 wzdz-slide1-tit">紧密结合定制建站四步骤-让建站高效起来</h2>
        </div>
        <div class="col-xs-6 wzdz-slide1-div">

            <p class="wzdz-slide1-p1">
                <span></span>网站定位
            </p>
            <hr>
            <p class="c6">企业品牌差异 核心产品优势 目标受众用户</p>
        </div>
        <div class="col-xs-6 wzdz-slide1-div">

            <p class="wzdz-slide1-p1">
                <span></span>快速开发
            </p>
            <hr>
            <p class="c6">拥有多年开发鹰眼</p>
        </div>
        <div class="col-xs-12 "></div>
        <div class="col-xs-6 wzdz-slide1-div">

            <p class="wzdz-slide1-p1">
                <span></span>原型设计
            </p>
            <hr>
            <p class="c6">策划设计PC/手机微网站，突出卖点 提升网站形象、综合实力，吸引访客，提高销售转化率</p>
        </div>
        <div class="col-xs-6 wzdz-slide1-div">

            <p class="wzdz-slide1-p1">
                <span></span>运营指导
            </p>
            <hr>
            <p class="c6">网站上线准备、网站ICP备案包申请、微信公众服务号包 申请 网站操作应用专业培训，快速掌握网站操作，从入门到实战掌握微营销应用</p>
        </div>

    </div>


</div>

<div class="col-xs-12 wzdz-slide2">


    <div class="col-xs-12 col-md-10 col-md-offset-1">

        <div class="col-xs-12">
            <h2 class=" wzdz-slide2-tit">黑珍珠建站与普通网站的区别</h2>
        </div>
        <div class="col-xs-12 wzdz-slide2-bg">
            <div class="col-xs-6 col-md-3 wzdz-slide2-p ">
                <p><span>。</span>专业团队定制策划，整站美观大气</p>
                <p><span>。</span>用户体验好，吸引访客咨询</p>
                <p><span>。</span>内置友好SEO，网站优化效果好</p>
                <p><span>。</span>PC+手机+微信网站三站合一，全 网营销</p>
                <p><span>。</span>专业运营指导</p>

            </div>

            <div class="col-xs-6 col-md-6">
                <img src="" width="100%" height="100%" alt="">
            </div>

            <div class="col-xs-6 col-md-3 wzdz-slide2-p ">
                <p><span>。</span>定位不清晰，设计呆板不美观</p>
                <p><span>。</span>用户体验不佳，访客关注度低</p>
                <p><span>。</span>无SEO优化，不利网站收录和排名</p>
                <p><span>。</span>只有单独的PC站或微信网站，营销不全面</p>
                <p><span>。</span>无后期增值培训和稳定的售后服务</p>

            </div>
        </div>


    </div>

</div>


<div class="col-xs-12 col-md-12 wzdz-slide3">

    <div class="col-xs-12 col-md-10 col-md-offset-1  wzdz-slide3-body">
        <div class="col-xs-12" style="padding-bottom: 30px;">
            <h2 class="wzdz-slide3-h2 wzdz-slide1-tit">
                网站整体解决方案
            </h2>
        </div>


        <div class="col-xs-6 col-md-3" >

            <div class="wzdz-slide3-div" >
                <p class="wzdz-slide3-div-titp" >
                    企业站
                </p>
                <p class="wzdz-slide3-div-topp">
                    PC站或手机微信站
                    <br>
                    5800元
                </p>
                <p>
                    精美创意Banner:3张以内
                </p>
                <p>
                    栏目：6个以内 <br>
                    内页：6个以内 <br>
                    产品：6个以内 <br>
                    文章：6个以内 <br>

                </p>
                <p>
                    交付周期：最快10个工作日
                </p>
           <p class="wzdz-slide3-div-botp">
               <a href="#" style=""> 点击咨询</a></p>
            </div>

        </div>
        <div class="col-xs-6 col-md-3" >

            <div class="wzdz-slide3-div" >
                <p class="wzdz-slide3-div-titp" >
                    营销站
                </p>
                <p class="wzdz-slide3-div-topp">
                    PC站或手机微信站
                    <br>
                    9800元
                </p>
                <p>
                    精美创意Banner:3张以内
                </p>
                <p>
                    栏目：10个以内 <br>
                    内页：10个以内 <br>
                    产品：10个以内 <br>
                    文章：10个以内 <br>

                </p>
                <p>
                    交付周期：最快10个工作日
                </p>
                <p class="wzdz-slide3-div-botp">
                    <a href="#" style=""> 点击咨询</a></p>
            </div>

        </div>
        <div class="col-xs-6 col-md-3" >

            <div class="wzdz-slide3-div" >
                <p class="wzdz-slide3-div-titp" >
                    营销领先
                </p>
                <p class="wzdz-slide3-div-topp">
                    PC站或手机微信站
                    <br>
                    15800元
                </p>
                <p>
                    精美创意Banner:5张以内
                </p>
                <p>
                    栏目：12个以内 <br>
                    内页：12个以内 <br>
                    产品：12个以内 <br>
                    文章：12个以内 <br>

                </p>
                <p>
                    交付周期：最快15个工作日
                </p>
                <p class="wzdz-slide3-div-botp">
                    <a href="#" style=""> 点击咨询</a></p>
            </div>

        </div>
        <div class="col-xs-6 col-md-3" >

            <div class="wzdz-slide3-div" >
                <p class="wzdz-slide3-div-titp" >
                    企业站
                </p>
                <p class="wzdz-slide3-div-topp">
                    PC站+手机+微信站
                    <br>
                    5800元
                </p>
                <p>
                    精美创意Banner:5张以内
                </p>
                <p>
                    栏目：15个以内 <br>
                    内页：15个以内 <br>
                    产品：15个以内 <br>
                    文章：15个以内 <br>

                </p>
                <p>
                    交付周期：最快20个工作日
                </p>
                <p class="wzdz-slide3-div-botp">
                    <a href="#" style=""> 点击咨询</a></p>
            </div>

        </div>




    </div>


</div>
<!--底部开始-->

<div class="col-xs-12 col-sm-12 col-md-12  slide4">

    <div class="col-md-10 col-md-offset-1">
        <div class="col-md-3  col-sm-12 col-xs-12" style="padding-left: 0;">
            <h3 class="slide4-zb">准备开展业务？</h3>
        </div>
        <div class="col-md-6">


            <div class="col-md-5 col-md-offset-1  col-sm-6 col-xs-6">
                <h4 class="slide4-but slide4-but1">
                    <a href="#">立即创建网站</a>
                </h4>
            </div>
            <div class="col-md-5   col-sm-6 col-xs-6">
                <h4 class="slide4-but slide4-but2">
                    <a href="#">成为渠道商</a>
                </h4>
            </div>

        </div>

        <div class="col-md-3   col-sm-6 col-xs-6  slide4-tel" style="text-align: right;margin-top: 30px;">或者拨打:
            0371-60297655
            <img src="_INDEX/images/7-24.png" width="100%" alt="">
        </div>
    </div>


    <!--slide4结束-->
</div>
<!--slide4结束-->

<div class="col-md-12 col-sm-12 col-xs-12 slide5">
    <div class="col-md-offset-1 col-md-10 col-xs-12 col-sm-12 slide5-top">


        <div class="col-md-3 col-sm-6 slide5-767">
            <p class="slide5-tit">联系我们</p>
            <p>河南·郑州 金水区创业园北林路16号</p>
            <p>联系电话：0371-60297655</p>
            <p>Email：n89@163.com</p>
            <p>邮编：450000</p>
            <img src="_INDEX/images/erweima.png" alt="二维码">
            <p class="max-display">
                <!-- JiaThis Button BEGIN -->
            <div class="jiathis_style_24x24 max-display">
                <a class="jiathis_button_weixin"></a>
                <a class="jiathis_button_tsina"></a>
                <a class="jiathis_button_qzone"></a>
                <a class="jiathis_button_tqq"></a>
                <a href="" class="jiathis jiathis_txt jtico jtico_jiathis"
                   target="_blank"></a>

            </div>
            <script type="text/javascript" src="http://v3.jiathis.com/code/jia.js" charset="utf-8"></script>
            <!-- JiaThis Button END -->
            </p>
        </div>
        <div class="col-md-3 col-sm-6 max-display">
            <p class="slide5-tit">"互联网+" 新闻中心</p>
            <p class="slide5-tit-2">加快HTML5开发可视化编辑器 </p>
            <p>随着HTML5游戏《围住神经猫》爆红网络， 越来越多的游戏开发者把目光投向HTML5领域。但是HTML5游戏...</p>
            <p class="slide5-tit-2">HTML5 Canvas中绘制矩形实例教程</p>
            <p>本文翻译自Steve Fulton Jeff Fulton HTML5Canvas, Chapter 2, The Basic RectangleShape. 让我们来看一下...</p>

        </div>
        <div class="col-sm-12 display-991">

        </div>
        <div class="col-md-3 col-sm-6 max-display">
            <p class="slide5-tit">产品与服务</p>

            <div class="col-md-6 col-sm-6 cpfw-tit">
                <p class="cpfw cpfw-a">
                    <a href="#">企业建站</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">定制网站</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">小程序开发</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">微信分销</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">网上开店</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">软件及系统开发服务</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">微信营销</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">SEO优化</a>
                </p>
                <p class="cpfw cpfw-a">
                    <a href="#">基础口碑服务</a>
                </p>

            </div>

            <div class="col-md-6 col-sm-6 cpfw-tit" style="text-align: right;padding-right: 15px;">
                <p class="cpfw cpfw-a">
                    <a href="#">代理政策</a>
                </p>

                <p class="cpfw cpfw-a">
                    <a href="#">代理流程</a>
                </p>

                <p class="cpfw cpfw-a">
                    <a href="#">代理注册</a>
                </p>

                <p class="cpfw cpfw-a">
                    <a href="#">代理咨询</a>
                </p>


            </div>
        </div>
        <div class="col-md-3 col-sm-6 max-display">
            <p class="slide5-tit">发送留言</p>
            <form>
                <div class="form-group">

                    <input type="name" class="form-control" id="exampleInputEmail1" placeholder="姓名">
                </div>
                <div class="form-group">

                    <input type="tel" class="form-control" id="exampleInputEmail1" placeholder="联系方式">
                </div>
                <div class="form-group">

                    <textarea class="form-control" rows="3" placeholder="留言内容"></textarea>
                </div>

                <button type="submit" class="btn btn-default btn-footer">提 交</button>
            </form>

        </div>


    </div>


</div>


<div class="col-md-12  col-xs-12 col-sm-12 footer-foot-top max-display-991">


    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-1 col-xs-12 footer-foot-body foot-body-1 max-display ">
        <a href="#">关于黑珍珠 |</a>
        <a href="#">联系我们 |</a>
        <a href="#">付款方式 |</a>
        <a href="#">网站备案 |</a>
        <a href="#">价格总览 |</a>
        <a href="#">帮助中心 |</a>
        <a href="#">诚聘英才 |</a>
        <a href="#">新闻中心 |</a>
        <a href="#">相关下载</a>
    </div>

    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-1 col-xs-12 footer-foot-body foot-body-2 max-display ">
        <a href="#">网站反馈 |</a>
        <a href="#">企业建站 |</a>
        <a href="#">软件开发 |</a>
        <a href="#">域名申请 |</a>
        <a href="#">虚拟主机 |</a>
        <a href="#">企业邮箱 |</a>
        <a href="#">营销推广 |</a>
        <a href="#">云主机 |</a>
        <a href="#">技术支持尽在黑珍珠</a>
    </div>

    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-1 col-xs-12 footer-foot-body foot-body-1 ">
        <p>© 2017黑珍珠科技备案号: <a href="#">豫ICP备 15011304-5号</a></p>
    </div>
</div>
<script src="_INDEX/style/addnav.js"></script>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="_INDEX/js/bootstrap.min.js"></script>
</body>
</html>