<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"/home/wwwroot/hzz.com/application/admin/view/index/member_level.html";i:1506773267;}*/ ?>
﻿<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<!--[if lt IE 9]>
<script type="text/javascript" src="_ADMIN/lib/html5shiv.js"></script>
<script type="text/javascript" src="_ADMIN/lib/respond.min.js"></script>
<![endif]-->
<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui/css/H-ui.min.css" />
<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/css/H-ui.admin.css" />
<link rel="stylesheet" type="text/css" href="_ADMIN/lib/Hui-iconfont/1.0.8/iconfont.css" />
<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/skin/default/skin.css" id="skin" />
<link rel="stylesheet" type="text/css" href="_ADMIN/static/h-ui.admin/css/style.css" />
<!--[if IE 6]>
<script type="text/javascript" src="_ADMIN/lib/DD_belatedPNG_0.0.8a-min.js" ></script>
<script>DD_belatedPNG.fix('*');</script>
<![endif]-->
<title>等级制度</title>
</head>
<body>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span> 会员管理 <span class="c-gray en">&gt;</span> 等级制度
	<a class="btn btn-success radius r" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a></nav>
<div class="page-container" style="padding-top: 0;">
	<div class="mt-20">
		<table class="table table-border table-bordered table-bg table-sort">
			<thead>
				<tr class="text-c">
					<th width="150">等级</th>

					<th width="200">积分</th>


					<th width="100">操作</th>
				</tr>
			</thead>
			<tbody>
				<tr class="text-c">

					<td class="text-l">普通会员</td>
					<td class="text-l">0</td>
					<td class="f-14 product-brand-manage"><a style="text-decoration:none" onClick="product_brand_edit('品牌编辑','codeing.html','1')" href="javascript:;" title="编辑"><i class="Hui-iconfont">&#xe6df;</i></a> <a style="text-decoration:none" class="ml-5" onClick="active_del(this,'10001')" href="javascript:;" title="删除"><i class="Hui-iconfont">&#xe6e2;</i></a></td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
					</tr>
				<tr class="text-c">

					<td class="text-l">白银代理商</td>
					<td class="text-l">5000</td>
					<td class="f-14 product-brand-manage"><a style="text-decoration:none" onClick="product_brand_edit('品牌编辑','codeing.html','1')" href="javascript:;" title="编辑"><i class="Hui-iconfont">&#xe6df;</i></a> <a style="text-decoration:none" class="ml-5" onClick="active_del(this,'10001')" href="javascript:;" title="删除"><i class="Hui-iconfont">&#xe6e2;</i></a></td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
				</tr>
				<tr class="text-c">

					<td class="text-l">黄金代理商</td>
					<td class="text-l">10000</td>
					<td class="f-14 product-brand-manage"><a style="text-decoration:none" onClick="product_brand_edit('品牌编辑','codeing.html','1')" href="javascript:;" title="编辑"><i class="Hui-iconfont">&#xe6df;</i></a> <a style="text-decoration:none" class="ml-5" onClick="active_del(this,'10001')" href="javascript:;" title="删除"><i class="Hui-iconfont">&#xe6e2;</i></a></td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
				</tr>
				<tr class="text-c">

					<td class="text-l">白金代理商</td>
					<td class="text-l">50000</td>
					<td class="f-14 product-brand-manage"><a style="text-decoration:none" onClick="product_brand_edit('品牌编辑','codeing.html','1')" href="javascript:;" title="编辑"><i class="Hui-iconfont">&#xe6df;</i></a> <a style="text-decoration:none" class="ml-5" onClick="active_del(this,'10001')" href="javascript:;" title="删除"><i class="Hui-iconfont">&#xe6e2;</i></a></td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
				</tr>
				<tr class="text-c">

					<td class="text-l">钻石代理商</td>
					<td class="text-l">100000</td>
					<td class="f-14 product-brand-manage"><a style="text-decoration:none" onClick="product_brand_edit('品牌编辑','codeing.html','1')" href="javascript:;" title="编辑"><i class="Hui-iconfont">&#xe6df;</i></a> <a style="text-decoration:none" class="ml-5" onClick="active_del(this,'10001')" href="javascript:;" title="删除"><i class="Hui-iconfont">&#xe6e2;</i></a></td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
					<td style="display: none;"> </td>
				</tr>

			</tbody>
		</table>

		<table class="table table-border table-bordered table-bg table-sort">
			<thead>
			<tr class="text-c">
				<th width="150">代理分成规则</th>


			</tr>
			</thead>
			<tbody>
			<tr class="text-c">

				<td class="text-l">根据不同等级进行不同的比例分成，根据每次的合同签署的金额增加积分。也可以直接交钱进行升级。具体细则正在完善中。</td>

			</tr>


			</tbody>
		</table>



	</div>
</div>
<!--_footer 作为公共模版分离出去-->
<script type="text/javascript" src="_ADMIN/lib/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="_ADMIN/lib/layer/2.4/layer.js"></script>
<script type="text/javascript" src="_ADMIN/static/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="_ADMIN/static/h-ui.admin/js/H-ui.admin.js"></script> <!--/_footer 作为公共模版分离出去-->

<!--请在下方写此页面业务相关的脚本-->
<script type="text/javascript" src="_ADMIN/lib/My97DatePicker/4.8/WdatePicker.js"></script> 
<script type="text/javascript" src="_ADMIN/lib/datatables/1.10.0/jquery.dataTables.min.js"></script> 
<script type="text/javascript" src="_ADMIN/lib/laypage/1.2/laypage.js"></script>
<script type="text/javascript">
//$('.table-sort').dataTable({
//	"aaSorting": [[ 1, "desc" ]],//默认第几个排序
//	"bStateSave": true,//状态保存
//	"aoColumnDefs": [
//	  //{"bVisible": false, "aTargets": [ 3 ]} //控制列的隐藏显示
//	  {"orderable":false,"aTargets":[0,6]}// 制定列不参与排序
//	]
//});
</script>
</body>
</html>