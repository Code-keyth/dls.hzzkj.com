/**
 * Created by cdc on 2017/10/17.
 */
    $(document).ready(function () {

        $(".nav-list-1,#nav-list-1").hover(function () {
            $("#nav-list-1").toggleClass("blue666");
        });

        $(".nav-list-2,#nav-list-2").hover(function () {
            $("#nav-list-2").toggleClass("blue666");
        });

        $(".nav-list-3,#nav-list-3").hover(function () {
            $("#nav-list-3").toggleClass("blue666");
        });

        $(".nav-list-4,#nav-list-4").hover(function () {
            $("#nav-list-4").toggleClass("blue666");
        });

        $(".nav-list-5,#nav-list-5").hover(function () {
            $("#nav-list-5").toggleClass("blue666");
        });

    });