package com.baidu.ueditor.define;

public enum ActionState {
	UNKNOW_ERROR
}
