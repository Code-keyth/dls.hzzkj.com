<?php
namespace app\index\controller;

use think\Controller;

class IndexController extends Controller
{
    public function index(){
        return $this->fetch();
    }
    public function head(){
        return $this->fetch();
    }
    public function footer(){
        return $this->fetch();
    }
    public function Agencyconsultation(){
        return $this->fetch();
    }

    public function Agencypolicy(){
        return $this->fetch();
    }
    public function Contactus(){
        return $this->fetch();
    }
    public function CrossborderTrade(){
        return $this->fetch();
    }
    public function Customized(){
        return $this->fetch();
    }
    public function DataopenAPI(){
        return $this->fetch();
    }
    public function EnterpriseCloud(){
        return $this->fetch();
    }
    public function ITservice(){
        return $this->fetch();
    }
    public function onlineshop(){
        return $this->fetch();
    }
    public function proxypattern(){
        return $this->fetch();
    }
    public function SEO(){
        return $this->fetch();
    }
    public function Serviceplatform(){
        return $this->fetch();
    }
    public function smallprogram(){
    return $this->fetch();
    }
    public function Station(){
        return $this->fetch();
    }
    public function Websitecase(){
        return $this->fetch();
    }
    public function WeChatdistribution(){
    return $this->fetch();
    }
    public function WeChatmarketing(){
        return $this->fetch();
    }
    public function Wordofmouth(){
    return $this->fetch();
    }




}
